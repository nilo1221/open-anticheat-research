===========================================================
PACCHETTO SCRIPT WINDOWS - Destiny 2 BattlEye Log Capture
===========================================================

CONTENUTO:
- mount_ssd.ps1: Script per montare automaticamente SSD esterno via SMB
- capture_battleye_logs.ps1: Script per catturare automaticamente log BattlEye

ISTRUZIONI:

1. MONTAGGIO SSD ESTERNO:
   - Apri PowerShell come amministratore
   - Esegui: PowerShell -ExecutionPolicy Bypass -File mount_ssd.ps1
   - Questo monterà l'SSD esterno come unità Z:

2. CATTURA LOG BATTLEYE:
   - Apri PowerShell come amministratore
   - Esegui: PowerShell -ExecutionPolicy Bypass -File capture_battleye_logs.ps1
   - Questo catturerà automaticamente i log BattlEye durante il gioco

CONFIGURAZIONE SMB:
- IP Host Linux: 192.168.1.59
- Condivisione: \\192.168.1.59\SteamLibrary
- Credenziali: lollo / lollo

Per problemi o supporto:
https://github.com/nilo1221/open-anticheat-research
